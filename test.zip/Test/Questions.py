class Question:
    def __init__(self, prompt, answer, per_score):
        self.prompt = prompt
        self.answer = answer
        self.per_score = per_score